<center>
    
    <h1> Meus pedidos</h1>
    
    
    <p class="lead"> Seus pedidos em um só lugar </p>
    
    <p class="text-muted">
        
         Se tiver qualquer dúvida, não hesite entrar em <a href="../contact.php">contato</a>. Nosso atendimento ao cliente funciona <strong>24h.</strong>   
        
    </p>
    
</center>


<hr>


<div class="table-responsive">
    
    <table class="table table-bordered table-hover">
        
        <thead>
            
            <tr>
                
                <th> ID:</th>
                <th> Valor a ser pago:</th>
                <th> Número do pedido: </th>
                <th> Quantidade: </th>
                <th> Tamanho:</th>
                <th> Data do pedido:</th>
                <th> Pago / Pendente: </th>
                <th> Status: </th>
                
            </tr>
            
        </thead>
        
        <tbody>
            
            <tr>
                
                <th> #1 </th>
                
                <td> R$240</td>
                <td> 3639862</td>
                <td> 2</td>
                <td> P</td>
                <td> 15-11-2023</td>
                <td> Pendente</td>
                
                <td>
                    
                    <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm"> Confirmar pagamento </a>
                    
                </td>
                
            </tr>
            
            <tr>
                
                <th> #2 </th>
                
                <td> R$240</td>
                <td> 3639862</td>
                <td> 2</td>
                <td> P</td>
                <td> 15-11-2023</td>
                <td> Pendente</td>
                
                <td>
                    
                    <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm"> Confirmar pagamento </a>
                    
                </td>
                
            </tr>
            
            <tr>
                
                <th> #3 </th>
                
                <td> R$240</td>
                <td> 3639862</td>
                <td> 2</td>
                <td> P</td>
                <td> 15-11-2023</td>
                <td> Pendente</td>
                
                <td>
                    
                    <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm"> Confirmar pagamento </a>
                    
                </td>
                
            </tr>
            
        </tbody>
        
    </table>
    
</div>