    <div id="footer"><!-- #footer Begin -->
        <div class="container"><!-- container Begin -->
            <div class="row"><!-- row Begin -->
                <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->

                    <h4>Páginas</h4>

                    <ul><!-- ul Begin -->
                        <li><a href="../cart.php">Carrinho</a></li>
                        <li><a href="../contact.php">Contato</a></li>
                        <li><a href="../shop.php">Shop</a></li>
                        <li><a href="my_account.php">Meu Perfil</a></li>
                    </ul><!-- ul Finish --> 

                    <hr>

                    <h4>Seção do usuário</h4>

                    <ul>
                        <li><a href="../checkout.php">Login</a></li>
                        <li><a href="../customer_register.php">Registrar</a></li>
                    </ul>  

                    <hr class="hidden-md hidden-lg hidden-sm">  

                </div><!-- col-sm-6 col-md-3 Finish -->

                <div class="com-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->

                   <h4>Principais categorias</h4>

                   <ul><!-- ul Begin -->
                       <li><a href="#">Roupas</a></li>
                       <li><a href="#">Periféricos</a></li>
                       <li><a href="#">Acessórios</a></li>
                       <li><a href="#">Colecionáveis</a></li>
                       <li><a href="#">Streaming</a></li>
                   </ul><!-- ul Finish -->

                    <hr class="hidden-md hidden-lg">

                </div><!-- col-sm-6 col-md-3 Finish -->

                <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->

                    <h4>Receba novidades</h4>

                    <p class="text-muted">
                        Fique por dentro das novidades, ofertas e muito mais! 
                    </p>

                    <form action="" method="post">
                        <div class="input-group">

                            <input type="text" class="form-control" name="email">

                            <span class="input-group-btn">

                                <input type="submit" value="Inscreva-se" class="btn btn-default">

                            </span>

                        </div>
                    </form>

                    <hr>

                    <h4>Siga nas redes sociais</h4>

                    <p class="social">
                        <a href="#" class="fa fa-facebook"></a>
                        <a href="#" class="fa fa-twitter"></a>
                        <a href="#" class="fa fa-instagram"></a>
                        <a href="#" class="fa fa-envelope"></a>
                        <a href="#" class="fa fa-youtube"></a>
                        <a href="#" class="fa fa-twitch"></a>

                    </p>

                </div><!-- col-sm-6 col-md-3 Finish -->

            </div><!-- row Finish -->
        </div><!-- container Finish -->
    </div><!-- #footer Finish -->


    <div id="copyright"><!-- copyright Begin -->
        <div class="container"><!-- container Begin -->
            <div class="col-md-6"><!-- col-md-6 Begin -->

               <p class="pull-left">&copy; 2023 GameGear Store | Todos os direitos reservados</p> 

            </div><!-- col-md-6 Finish -->
            <div class="col-md-6"><!-- col-md-6 Begin -->

               <p class="pull-left">Theme by: <a href="#">João Vítor e Everson</a></p> 

            </div><!-- col-md-6 Finish -->
        </div><!-- container Finish -->
    </div><!-- copyright Finish -->